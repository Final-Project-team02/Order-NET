package bitc.fullstack503.ordernetserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderNetServerApplicationTests {

  @Test
  void contextLoads() {
  }

}
