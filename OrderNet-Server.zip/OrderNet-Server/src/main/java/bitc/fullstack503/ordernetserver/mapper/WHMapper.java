package bitc.fullstack503.ordernetserver.mapper;

import bitc.fullstack503.ordernetserver.dto.WHDTO;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
import java.util.Map;

@Mapper
public interface WHMapper {

    //    물류센터 재고조회
    List<WHDTO> selectWHStock(String userId);

    // 물류센터 입고조회
    List<WHDTO> selectWHComeIn(String userId);

    //    재고관리 조회
    List<WHDTO> selectWHManage(String userId);


    void updateOrderStatus(int orderItemId, String orderItemStatus);

    List<WHDTO> selectWHManageFiltered(Map<String, Object> paramMap);

}
