package bitc.fullstack503.ordernetserver.service;

import bitc.fullstack503.ordernetserver.dto.WHDTO;
import bitc.fullstack503.ordernetserver.mapper.WHMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class WHServiceImpl implements WHService {

    @Autowired
    private WHMapper whMapper;



    //    물류센터 입고조회
    @Override
    public List<WHDTO> selectWHComeIn(String userId) {
        return whMapper.selectWHComeIn(userId);
    }

    //    물류센터 재고조회
    @Override
    public List<WHDTO> selectWHStock(String userId) {
        return whMapper.selectWHStock(userId);

    }

    //    재고관리 조회
    @Override
    public List<WHDTO> selectWHManage(String userId) {
        return whMapper.selectWHManage(userId);
    }

    @Override
    public void updateOrderStatus(int orderItemId, String orderItemStatus) {
        whMapper.updateOrderStatus(orderItemId, orderItemStatus);
    }

    @Override
    public List<WHDTO> selectWHManageFiltered(String userId, String orderItemStatus, String branchName,
                                              String orderId, String orderStartDate, String orderEndDate) {
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put("userId", userId);
        paramMap.put("orderItemStatus", orderItemStatus);
        paramMap.put("branchName", branchName);
        paramMap.put("orderId", orderId);
        paramMap.put("orderStartDate", orderStartDate);
        paramMap.put("orderEndDate", orderEndDate);

        return whMapper.selectWHManageFiltered(paramMap); // Mapper에서 필터링된 데이터 반환
    }


    }



