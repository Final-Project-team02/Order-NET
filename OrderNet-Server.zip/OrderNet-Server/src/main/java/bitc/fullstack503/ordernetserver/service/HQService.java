package bitc.fullstack503.ordernetserver.service;

public interface HQService {
}
