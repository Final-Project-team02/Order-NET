package bitc.fullstack503.ordernetserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrderNetServerApplication {

  public static void main(String[] args) {
    SpringApplication.run(OrderNetServerApplication.class, args);
  }

}
